# Prism 2.0 (Fabric, Minecraft 1.21.11)

Визуальный клиентский мод. Структура (категории → модули → настройки, меню, HUD) сделана
по образцу SoupVisuals, но весь код и ресурсы — оригинальные (лицензия SOUP-1.0 запрещает копирование).

**Меню: Ctrl + Shift + Y** (повторно — закрыть). Настройки: `config/prism.json`.

| Категория | Модули |
|---|---|
| Visuals | **Hitboxes** (кастомный цвет, RGB-режим, отдельный цвет таргета), **TargetRender** (пульсирующее кольцо вокруг цели), JumpCircles, Trails |
| HUD | Watermark, **TargetHud** (имя, HP, дистанция), ModulesList, Notifications |
| Client | **Theme** — основной цвет интерфейса (по умолчанию фиолетовый #8B5CF6), можно включить RGB |

У каждого цвета есть ползунки R/G/B, переключатель **RGB mode** и скорость цикла.

## Сборка
1. JDK 21 + Gradle. 2. `gradle wrapper`, затем `./gradlew build`.
3. `build/libs/prism-2.0.0.jar` → папка `mods` (нужны Fabric Loader и Fabric API).

Версии в `gradle.properties` сверьте с https://fabricmc.net/develop.
Мировой рендер — только в `PrismRender.java`; при ошибках после обновления правьте там.
