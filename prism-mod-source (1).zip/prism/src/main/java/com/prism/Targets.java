package com.prism;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

/** Текущая цель: живое существо под прицелом (запоминается на время). */
public final class Targets {
    private static LivingEntity last;
    private static long lastTime;

    public static void tick(MinecraftClient mc) {
        if (mc.targetedEntity instanceof LivingEntity le && le != mc.player) {
            last = le; lastTime = System.currentTimeMillis();
        }
    }

    public static LivingEntity current(long holdMs) {
        if (last == null || last.isRemoved() || !last.isAlive()) return null;
        return System.currentTimeMillis() - lastTime <= holdMs ? last : null;
    }
}
