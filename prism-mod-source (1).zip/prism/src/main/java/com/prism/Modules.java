package com.prism;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Все модули Prism. Структура (категории / модули / настройки) — по образцу SoupVisuals, код оригинальный. */
public final class Modules {
    private Modules() {}

    public static final ThemeModule THEME = new ThemeModule();
    public static final Hitboxes HITBOXES = new Hitboxes();
    public static final TargetRender TARGET_RENDER = new TargetRender();
    public static final JumpCircles JUMP_CIRCLES = new JumpCircles();
    public static final Trails TRAILS = new Trails();
    public static final Watermark WATERMARK = new Watermark();
    public static final TargetHud TARGET_HUD = new TargetHud();
    public static final ModulesList MODULES_LIST = new ModulesList();
    public static final NotifyModule NOTIFY = new NotifyModule();

    static int theme(float off) { return THEME.main.get(off); }
    static int argb(int rgb) { return 0xFF000000 | rgb; }

    static Box boxOf(Entity e, float td) {
        double x = MathHelper.lerp(td, e.lastRenderX, e.getX());
        double y = MathHelper.lerp(td, e.lastRenderY, e.getY());
        double z = MathHelper.lerp(td, e.lastRenderZ, e.getZ());
        return e.getDimensions(e.getPose()).getBoxAt(x, y, z);
    }

    // ───────────── CLIENT ─────────────
    public static class ThemeModule extends Module {
        public final Setting.Col main = add(new Setting.Col("Main color", 0x8B5CF6, false));
        ThemeModule() { super("Theme", Category.CLIENT, true); }
    }

    // ───────────── VISUALS ─────────────
    /** Хитбоксы с кастомным цветом, RGB-режимом и отдельным цветом таргета. */
    public static class Hitboxes extends Module {
        final Setting.Bool playersOnly = add(new Setting.Bool("Players only", true));
        final Setting.Bool highlight = add(new Setting.Bool("Highlight target", true));
        final Setting.Col color = add(new Setting.Col("Hitbox color", 0x8B5CF6, true));
        final Setting.Col targetColor = add(new Setting.Col("Target color", 0xFF3B6B, false));
        Hitboxes() { super("Hitboxes", Category.VISUALS, true); }

        @Override
        public void onRender3D(MinecraftClient mc, MatrixStack ms, VertexConsumer vc, Vec3d cam, float td) {
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || e.isInvisible()) continue;
                boolean ok = playersOnly.value ? e instanceof PlayerEntity : e instanceof LivingEntity;
                if (!ok) continue;
                boolean isTarget = highlight.value && e == mc.targetedEntity;
                int col = isTarget ? targetColor.get() : color.get();
                RenderUtil.box(ms, vc, boxOf(e, td).offset(-cam.x, -cam.y, -cam.z), col, 1f);
            }
        }
    }

    /** Пульсирующее кольцо вокруг цели. */
    public static class TargetRender extends Module {
        final Setting.Col color = add(new Setting.Col("Ring color", 0xFF3B6B, false));
        final Setting.Num speed = add(new Setting.Num("Speed", 2.0, 0.5, 6, 0.5));
        final Setting.Num hold = add(new Setting.Num("Hold (ms)", 1500, 0, 5000, 100));
        TargetRender() { super("TargetRender", Category.VISUALS, true); }

        @Override
        public void onRender3D(MinecraftClient mc, MatrixStack ms, VertexConsumer vc, Vec3d cam, float td) {
            LivingEntity t = Targets.current((long) hold.value);
            if (t == null) return;
            Box b = boxOf(t, td);
            double cx = (b.minX + b.maxX) / 2, cz = (b.minZ + b.maxZ) / 2;
            double r = (b.maxX - b.minX) * 0.9 + 0.15;
            double ph = (Math.sin(System.currentTimeMillis() / 1000.0 * speed.value * 2) + 1) / 2;
            int col = color.get();
            RenderUtil.ring(ms, vc, cam, cx, b.minY + 0.02, cz, r, col, 0.6f);
            RenderUtil.ring(ms, vc, cam, cx, b.minY + ph * (b.maxY - b.minY), cz, r, col, 1f);
        }
    }

    /** Расходящееся кольцо при прыжке. */
    public static class JumpCircles extends Module {
        record Circle(double x, double y, double z, long t) {}
        final Setting.Col color = add(new Setting.Col("Color", 0x8B5CF6, true));
        final Setting.Num radius = add(new Setting.Num("Radius", 1.5, 0.5, 4, 0.1));
        final Setting.Num life = add(new Setting.Num("Life (ms)", 900, 300, 2500, 100));
        private final List<Circle> list = new ArrayList<>();
        private boolean wasGround = true;
        JumpCircles() { super("JumpCircles", Category.VISUALS, false); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.player == null) return;
            boolean g = mc.player.isOnGround();
            if (wasGround && !g && mc.player.getVelocity().y > 0.1)
                list.add(new Circle(mc.player.getX(), mc.player.getY(), mc.player.getZ(), System.currentTimeMillis()));
            wasGround = g;
            long now = System.currentTimeMillis();
            list.removeIf(c -> now - c.t() > life.value);
        }

        @Override
        public void onRender3D(MinecraftClient mc, MatrixStack ms, VertexConsumer vc, Vec3d cam, float td) {
            long now = System.currentTimeMillis();
            for (Circle c : list) {
                double p = Math.min(1, (now - c.t()) / life.value);
                double eased = 1 - (1 - p) * (1 - p);
                RenderUtil.ring(ms, vc, cam, c.x(), c.y() + 0.02, c.z(), 0.2 + eased * radius.value,
                        color.get((float) p * 0.3f), (float) (1 - p));
            }
        }
    }

    /** След за игроком (виден в виде от 3-го лица). */
    public static class Trails extends Module {
        final Setting.Col color = add(new Setting.Col("Color", 0x8B5CF6, true));
        final Setting.Num length = add(new Setting.Num("Length", 40, 10, 120, 5));
        private final java.util.ArrayDeque<Vec3d> pts = new java.util.ArrayDeque<>();
        Trails() { super("Trails", Category.VISUALS, false); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.player == null) return;
            pts.addLast(new Vec3d(mc.player.getX(), mc.player.getY() + 0.1, mc.player.getZ()));
            while (pts.size() > length.value) pts.removeFirst();
        }

        @Override
        public void onRender3D(MinecraftClient mc, MatrixStack ms, VertexConsumer vc, Vec3d cam, float td) {
            if (mc.options.getPerspective().isFirstPerson()) return;
            int i = 0, n = pts.size();
            for (Vec3d p : pts) {
                float k = (float) i++ / Math.max(1, n);
                Box b = new Box(p.x - .06, p.y, p.z - .06, p.x + .06, p.y + .12, p.z + .06).offset(-cam.x, -cam.y, -cam.z);
                RenderUtil.box(ms, vc, b, color.get(k * 0.5f), k);
            }
        }
    }

    // ───────────── HUD ─────────────
    public static class Watermark extends Module {
        Watermark() { super("Watermark", Category.HUD, true); }

        @Override
        public void onHud(DrawContext c, MinecraftClient mc) {
            String s = "Prism  |  " + mc.getCurrentFps() + " fps  |  " + mc.player.getName().getString();
            int w = mc.textRenderer.getWidth(s) + 14, x = 6, y = 6;
            RenderUtil.panel(c, x, y, w, 16, 0xC00D0620);
            for (int i = 0; i < w; i += 2) c.fill(x + i, y, x + Math.min(i + 2, w), y + 1, argb(theme(i / (float) w * 0.5f)));
            c.drawTextWithShadow(mc.textRenderer, "Prism", x + 7, y + 4, argb(theme(0)));
            c.drawTextWithShadow(mc.textRenderer, s.substring(5), x + 7 + mc.textRenderer.getWidth("Prism"), y + 4, 0xFFFFFFFF);
        }
    }

    public static class TargetHud extends Module {
        final Setting.Num hold = add(new Setting.Num("Hold (ms)", 2000, 0, 5000, 100));
        final Setting.Num offX = add(new Setting.Num("Offset X", 30, -300, 300, 5));
        final Setting.Num offY = add(new Setting.Num("Offset Y", 30, -200, 200, 5));
        private float shown;
        TargetHud() { super("TargetHud", Category.HUD, true); }

        @Override
        public void onHud(DrawContext c, MinecraftClient mc) {
            LivingEntity t = Targets.current((long) hold.value);
            if (t == null) return;
            int w = 140, h = 40;
            int x = c.getScaledWindowWidth() / 2 + (int) offX.value, y = c.getScaledWindowHeight() / 2 + (int) offY.value;
            float hp = t.getHealth(), max = Math.max(1f, t.getMaxHealth());
            shown += (hp - shown) * 0.15f;
            RenderUtil.panel(c, x, y, w, h, 0xC00D0620);
            c.fill(x, y + 2, x + 2, y + h - 2, argb(theme(0)));
            c.drawTextWithShadow(mc.textRenderer, t.getName().getString(), x + 8, y + 6, 0xFFFFFFFF);
            String info = String.format("%.1f HP  |  %.1fm", hp, mc.player.distanceTo(t));
            c.drawTextWithShadow(mc.textRenderer, info, x + 8, y + 17, 0xFFC4B5FD);
            int bw = w - 16, fill = (int) (bw * Math.min(1f, shown / max));
            c.fill(x + 8, y + 29, x + 8 + bw, y + 33, 0xFF2A1A55);
            for (int i = 0; i < fill; i += 2)
                c.fill(x + 8 + i, y + 29, x + 8 + Math.min(i + 2, fill), y + 33, argb(theme(i / (float) bw * 0.5f)));
        }
    }

    public static class ModulesList extends Module {
        ModulesList() { super("ModulesList", Category.HUD, true); }

        @Override
        public void onHud(DrawContext c, MinecraftClient mc) {
            List<Module> on = new ArrayList<>();
            for (Module m : ModuleManager.ALL) if (m.enabled && m != THEME && m != this) on.add(m);
            on.sort((a, b) -> mc.textRenderer.getWidth(b.name) - mc.textRenderer.getWidth(a.name));
            int sw = c.getScaledWindowWidth(), y = 4, i = 0;
            for (Module m : on) {
                int tw = mc.textRenderer.getWidth(m.name);
                int x = sw - tw - 10;
                RenderUtil.panel(c, x, y, tw + 8, 12, 0xA00D0620);
                c.fill(sw - 2, y, sw, y + 12, argb(theme(i * 0.07f)));
                c.drawTextWithShadow(mc.textRenderer, m.name, x + 4, y + 2, argb(theme(i * 0.07f)));
                y += 13; i++;
            }
        }
    }

    public static class NotifyModule extends Module {
        record Note(String text, boolean on, long t) {}
        private final List<Note> notes = new ArrayList<>();
        NotifyModule() { super("Notifications", Category.HUD, true); }

        public void push(String text, boolean on) { if (enabled || text.startsWith("Notifications")) notes.add(new Note(text, on, System.currentTimeMillis())); }

        @Override
        public void onHud(DrawContext c, MinecraftClient mc) {
            long now = System.currentTimeMillis();
            notes.removeIf(n -> now - n.t() > 2500);
            int sw = c.getScaledWindowWidth(), sh = c.getScaledWindowHeight(), i = 0;
            for (Note n : notes) {
                int w = mc.textRenderer.getWidth(n.text()) + 20;
                double in = Math.min(1, (now - n.t()) / 250.0);
                int x = sw - w - 8 + (int) ((1 - in * (2 - in)) * (w + 10));
                int y = sh - 40 - i * 22;
                RenderUtil.panel(c, x, y, w, 18, 0xD00D0620);
                c.fill(x, y + 2, x + 2, y + 16, n.on() ? argb(theme(0)) : 0xFF6B7280);
                c.drawTextWithShadow(mc.textRenderer, n.text(), x + 10, y + 5, 0xFFFFFFFF);
                i++;
            }
        }
    }
}
