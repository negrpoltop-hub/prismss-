package com.prism;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import org.lwjgl.glfw.GLFW;

public class PrismClient implements ClientModInitializer {
    private static boolean wasDown = false;

    private static boolean down(long w, int key) { return GLFW.glfwGetKey(w, key) == GLFW.GLFW_PRESS; }

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        // Меню: Ctrl + Shift + Y (повторное нажатие закрывает)
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            long w = mc.getWindow().getHandle();
            boolean ctrl = down(w, GLFW.GLFW_KEY_LEFT_CONTROL) || down(w, GLFW.GLFW_KEY_RIGHT_CONTROL);
            boolean shift = down(w, GLFW.GLFW_KEY_LEFT_SHIFT) || down(w, GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean combo = ctrl && shift && down(w, GLFW.GLFW_KEY_Y);
            if (combo && !wasDown) {
                if (mc.currentScreen instanceof PrismScreen || mc.currentScreen instanceof ModuleScreen) {
                    ModuleManager.save();
                    mc.setScreen(null);
                } else if (mc.currentScreen == null) {
                    mc.setScreen(new PrismScreen());
                }
            }
            wasDown = combo;
            ModuleManager.tick(mc);
        });

        PrismRender.register();
        HudRenderCallback.EVENT.register((ctx, tick) ->
                ModuleManager.hud(ctx, net.minecraft.client.MinecraftClient.getInstance()));
    }
}
