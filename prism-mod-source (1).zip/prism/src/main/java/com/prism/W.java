package com.prism;

import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.DoubleConsumer;

/** Мелкие GUI-хелперы. */
final class W {
    static Text onOff(String n, boolean v) {
        return Text.literal(n + ": " + (v ? "ON" : "OFF")).styled(s -> s.withColor(v ? 0xC4B5FD : 0x9CA3AF));
    }

    static class Slider extends SliderWidget {
        private final String label;
        private final double min, max, step;
        private final DoubleConsumer set;

        Slider(int x, int y, int w, String label, double min, double max, double step, double cur, DoubleConsumer set) {
            super(x, y, w, 20, Text.empty(), Math.max(0, Math.min(1, (cur - min) / (max - min))));
            this.label = label; this.min = min; this.max = max; this.step = step; this.set = set;
            updateMessage();
        }

        private double val() {
            double v = min + value * (max - min);
            return step > 0 ? Math.round(v / step) * step : v;
        }

        @Override protected void updateMessage() {
            double v = val();
            setMessage(Text.literal(label + ": " + (step >= 1 ? String.valueOf((int) v) : String.format("%.1f", v))));
        }
        @Override protected void applyValue() { set.accept(val()); }
    }
}
