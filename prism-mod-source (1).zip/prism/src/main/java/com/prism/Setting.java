package com.prism;

import com.google.gson.JsonObject;

/** Настройки модулей: Bool, Num, Col (цвет + RGB-режим). */
public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }
    public abstract void save(JsonObject o);
    public abstract void load(JsonObject o);

    public static class Bool extends Setting {
        public boolean value;
        public Bool(String n, boolean v) { super(n); value = v; }
        public void save(JsonObject o) { o.addProperty(name, value); }
        public void load(JsonObject o) { if (o.has(name)) value = o.get(name).getAsBoolean(); }
    }

    public static class Num extends Setting {
        public double value, min, max, step;
        public Num(String n, double v, double min, double max, double step) {
            super(n); value = v; this.min = min; this.max = max; this.step = step;
        }
        public void save(JsonObject o) { o.addProperty(name, value); }
        public void load(JsonObject o) { if (o.has(name)) value = o.get(name).getAsDouble(); }
    }

    /** Цвет 0xRRGGBB; при rainbow=true плавно меняется по кругу HSB (RGB-режим). */
    public static class Col extends Setting {
        public int rgb;
        public boolean rainbow;
        public double speed = 4; // секунд на полный круг
        public Col(String n, int rgb, boolean rainbow) { super(n); this.rgb = rgb; this.rainbow = rainbow; }

        public int get() { return get(0f); }

        /** offset (0..1) сдвигает оттенок — для градиентов в списках и HUD. */
        public int get(float offset) {
            if (!rainbow) return rgb;
            float period = (float) Math.max(0.5, speed) * 1000f;
            float hue = ((System.currentTimeMillis() % (long) period) / period + offset) % 1f;
            if (hue < 0) hue += 1f;
            return hsv(hue, 0.85f, 1f);
        }

        /** HSV → 0xRRGGBB без java.awt. */
        static int hsv(float h, float s, float v) {
            float x = h * 6f;
            int i = (int) Math.floor(x);
            float f = x - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
            float r, g, b;
            switch (i % 6) {
                case 0 -> { r = v; g = t; b = p; }
                case 1 -> { r = q; g = v; b = p; }
                case 2 -> { r = p; g = v; b = t; }
                case 3 -> { r = p; g = q; b = v; }
                case 4 -> { r = t; g = p; b = v; }
                default -> { r = v; g = p; b = q; }
            }
            return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
        }

        public void save(JsonObject o) {
            JsonObject c = new JsonObject();
            c.addProperty("rgb", rgb); c.addProperty("rainbow", rainbow); c.addProperty("speed", speed);
            o.add(name, c);
        }
        public void load(JsonObject o) {
            if (!o.has(name)) return;
            JsonObject c = o.getAsJsonObject(name);
            if (c.has("rgb")) rgb = c.get("rgb").getAsInt();
            if (c.has("rainbow")) rainbow = c.get("rainbow").getAsBoolean();
            if (c.has("speed")) speed = c.get("speed").getAsDouble();
        }
    }
}
