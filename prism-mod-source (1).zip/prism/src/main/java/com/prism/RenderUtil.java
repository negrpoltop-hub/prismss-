package com.prism;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class RenderUtil {
    public static void box(MatrixStack ms, VertexConsumer vc, Box b, int rgb, float a) {
        VertexRendering.drawBox(ms, vc, b, ((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, a);
    }

    /** Кольцо из маленьких боксов (используется только drawBox — самый стабильный вызов). */
    public static void ring(MatrixStack ms, VertexConsumer vc, Vec3d cam, double x, double y, double z,
                            double radius, int rgb, float a) {
        int n = Math.max(24, (int) (radius * 28));
        for (int i = 0; i < n; i++) {
            double ang = i * Math.PI * 2 / n;
            double px = x + Math.cos(ang) * radius, pz = z + Math.sin(ang) * radius;
            Box b = new Box(px - .025, y, pz - .025, px + .025, y + .03, pz + .025).offset(-cam.x, -cam.y, -cam.z);
            box(ms, vc, b, rgb, a);
        }
    }

    /** Панель со слегка скруглёнными углами. */
    public static void panel(DrawContext c, int x, int y, int w, int h, int argb) {
        c.fill(x + 2, y, x + w - 2, y + h, argb);
        c.fill(x, y + 2, x + w, y + h - 2, argb);
        c.fill(x + 1, y + 1, x + w - 1, y + h - 1, argb);
    }
}
