package com.prism;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.math.Vec3d;

/**
 * Единственная точка, где мод касается мирового рендера (Fabric API 0.141, MC 1.21.11:
 * события лежат в пакете rendering.v1.world, камера — в worldState().cameraRenderState).
 */
public class PrismRender {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(PrismRender::render);
    }

    private static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || ctx.consumers() == null) return;
        float td = mc.getRenderTickCounter().getTickProgress(false);
        Vec3d cam = ctx.worldState().cameraRenderState.pos;
        VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
        ModuleManager.render3D(mc, ctx.matrices(), vc, cam, td);
    }
}
